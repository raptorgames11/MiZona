import TiendaScreen from './TiendaScreen';
import MapaScreen from './MapaScreen';
import LoginScreen from './LoginScreen';
import TaxisScreen from './TaxisScreen';
import TrufisScreen from './TrufisScreen';
import ChoferScreen from './ChoferScreen';
import { useState, useEffect } from 'react';
import {
  View, Text, TextInput, ScrollView,
  TouchableOpacity, StyleSheet, Linking, SafeAreaView
} from 'react-native';
import { obtenerProductos } from './firebase';

export default function App() {
  const [busqueda, setBusqueda] = useState('');
  const [pantalla, setPantalla] = useState('inicio');
  const [productos, setProductos] = useState([]);
  const [tiendas, setTiendas] = useState([]);
  const [tiendaActual, setTiendaActual] = useState(null);

  useEffect(() => { cargarProductos(); }, []);

  const cargarProductos = async () => {
    try {
      const datos = await obtenerProductos();
      setProductos(datos);
      const tiendasUnicas = [...new Set(datos.map(p => p.tienda))].map((nombre, i) => ({
        id: i + 1, nombre,
        distancia: `${(i + 1) * 150}m`,
        productos: datos.filter(p => p.tienda === nombre).length,
        whatsapp: '59170000001',
      }));
      setTiendas(tiendasUnicas);
    } catch (e) {}
  };

  const productosFiltrados = productos.filter(p =>
    p.nombre.toLowerCase().includes(busqueda.toLowerCase())
  );

  const abrirWhatsApp = (numero) => Linking.openURL(`https://wa.me/${numero}`);

  const Navbar = ({ actual }) => (
    <View style={s.navbar}>
      <TouchableOpacity style={s.navItem} onPress={() => { setPantalla('inicio'); cargarProductos(); }}>
        <Text style={s.navIcon}>🏠</Text>
        <Text style={[s.navLabel, actual === 'inicio' && s.navActivo]}>Inicio</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.navItem} onPress={() => setPantalla('mapa')}>
        <Text style={s.navIcon}>🗺️</Text>
        <Text style={[s.navLabel, actual === 'mapa' && s.navActivo]}>Mapa</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.navItem} onPress={() => setPantalla('taxis')}>
        <Text style={s.navIcon}>🚕</Text>
        <Text style={[s.navLabel, actual === 'taxis' && s.navActivo]}>Taxis</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.navItem} onPress={() => setPantalla('trufis')}>
        <Text style={s.navIcon}>🚗</Text>
        <Text style={[s.navLabel, actual === 'trufis' && s.navActivo]}>Trufis</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.navItem} onPress={() => setPantalla('chofer')}>
        <Text style={s.navIcon}>🚖</Text>
        <Text style={[s.navLabel, actual === 'chofer' && s.navActivo]}>Chofer</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.navItem} onPress={() => setPantalla('tienda')}>
        <Text style={s.navIcon}>🏪</Text>
        <Text style={[s.navLabel, actual === 'tienda' && s.navActivo]}>Tienda</Text>
      </TouchableOpacity>
    </View>
  );

  if (pantalla === 'mapa') return <View style={{ flex: 1 }}><MapaScreen busqueda={busqueda} /><Navbar actual="mapa" /></View>;
  if (pantalla === 'taxis') return <View style={{ flex: 1 }}><TaxisScreen /><Navbar actual="taxis" /></View>;
  if (pantalla === 'trufis') return <View style={{ flex: 1 }}><TrufisScreen /><Navbar actual="trufis" /></View>;
  if (pantalla === 'chofer') return <View style={{ flex: 1 }}><ChoferScreen /><Navbar actual="chofer" /></View>;
  if (pantalla === 'tienda') {
    return (
      <View style={{ flex: 1 }}>
        {tiendaActual ? (
          <TiendaScreen tienda={tiendaActual} onCerrar={() => setTiendaActual(null)} />
        ) : (
          <LoginScreen onLogin={(t) => setTiendaActual(t)} />
        )}
        <Navbar actual="tienda" />
      </View>
    );
  }

  return (
    <SafeAreaView style={s.container}>
      <View style={s.topbar}>
        <Text style={s.titulo}>MiZona</Text>
        <Text style={s.subtitulo}>Encuentra productos cerca de ti</Text>
        <TextInput
          style={s.buscador}
          placeholder="Buscar producto..."
          placeholderTextColor="rgba(255,255,255,0.6)"
          value={busqueda}
          onChangeText={setBusqueda}
        />
      </View>

      <ScrollView style={s.scroll}>
        <Text style={s.seccion}>Productos ({productosFiltrados.length})</Text>
        {productosFiltrados.length === 0 && <View style={s.centro}><Text style={s.vacio}>No hay productos aún</Text></View>}
        {productosFiltrados.map(p => (
          <View key={p.id} style={s.productoCard}>
            <View style={s.productoInfo}>
              <Text style={s.productoNombre}>{p.nombre}</Text>
              <Text style={s.productoTienda}>{p.tienda}</Text>
            </View>
            <View style={s.productoDerecha}>
              <Text style={s.productoPrecio}>Bs. {p.precio}</Text>
              <View style={[s.badge, p.stock ? s.badgeVerde : s.badgeRojo]}>
                <Text style={[s.badgeTexto, p.stock ? s.badgeTextoVerde : s.badgeTextoRojo]}>
                  {p.stock ? 'En stock' : 'Sin stock'}
                </Text>
              </View>
            </View>
          </View>
        ))}

        <Text style={s.seccion}>Tiendas ({tiendas.length})</Text>
        {tiendas.map(t => (
          <View key={t.id} style={s.tiendaCard}>
            <View style={s.tiendaAvatar}>
              <Text style={s.tiendaAvatarTexto}>{t.nombre.charAt(0)}</Text>
            </View>
            <View style={s.tiendaInfo}>
              <Text style={s.tiendaNombre}>{t.nombre}</Text>
              <Text style={s.tiendaDist}>{t.distancia} · {t.productos} productos</Text>
            </View>
            <TouchableOpacity style={s.waBtn} onPress={() => abrirWhatsApp(t.whatsapp)}>
              <Text style={s.waBtnTexto}>WhatsApp</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
      <Navbar actual="inicio" />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  topbar: { backgroundColor: '#1D9E75', padding: 16, paddingTop: 40 },
  titulo: { fontSize: 20, fontWeight: '600', color: 'white' },
  subtitulo: { fontSize: 12, color: '#9FE1CB', marginTop: 2 },
  buscador: { backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 8, padding: 10, marginTop: 10, color: 'white', fontSize: 14 },
  scroll: { flex: 1 },
  centro: { alignItems: 'center', padding: 32 },
  vacio: { fontSize: 14, color: '#888' },
  seccion: { fontSize: 12, fontWeight: '600', color: '#888', padding: 16, paddingBottom: 8, textTransform: 'uppercase', letterSpacing: 1 },
  productoCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: 'white', marginHorizontal: 12, marginBottom: 8, borderRadius: 10, padding: 12, borderWidth: 0.5, borderColor: '#e0e0e0' },
  productoInfo: { flex: 1 },
  productoNombre: { fontSize: 14, fontWeight: '500', color: '#222' },
  productoTienda: { fontSize: 12, color: '#888', marginTop: 2 },
  productoDerecha: { alignItems: 'flex-end' },
  productoPrecio: { fontSize: 14, fontWeight: '600', color: '#1D9E75' },
  badge: { marginTop: 4, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  badgeVerde: { backgroundColor: '#E1F5EE' },
  badgeRojo: { backgroundColor: '#FCEBEB' },
  badgeTexto: { fontSize: 11 },
  badgeTextoVerde: { color: '#085041' },
  badgeTextoRojo: { color: '#A32D2D' },
  tiendaCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'white', marginHorizontal: 12, marginBottom: 8, borderRadius: 10, padding: 12, borderWidth: 0.5, borderColor: '#e0e0e0' },
  tiendaAvatar: { width: 40, height: 40, borderRadius: 10, backgroundColor: '#5DCAA5', alignItems: 'center', justifyContent: 'center' },
  tiendaAvatarTexto: { fontSize: 16, fontWeight: '600', color: '#04342C' },
  tiendaInfo: { flex: 1, marginLeft: 10 },
  tiendaNombre: { fontSize: 14, fontWeight: '500', color: '#222' },
  tiendaDist: { fontSize: 12, color: '#888', marginTop: 2 },
  waBtn: { backgroundColor: '#1D9E75', borderRadius: 6, paddingHorizontal: 10, paddingVertical: 6 },
  waBtnTexto: { color: 'white', fontSize: 12, fontWeight: '500' },
  navbar: { flexDirection: 'row', backgroundColor: 'white', borderTopWidth: 0.5, borderTopColor: '#e0e0e0', paddingVertical: 8 },
  navItem: { flex: 1, alignItems: 'center' },
  navIcon: { fontSize: 16 },
  navLabel: { fontSize: 9, color: '#888', marginTop: 2 },
  navActivo: { color: '#1D9E75', fontWeight: '500' },
});